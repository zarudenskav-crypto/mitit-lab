Option Explicit

Dim shell, fso, pdfPath, result

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

MsgBox "MITIT UNDER THE ATTACK", 64, "Security Lab"

pdfPath = fso.GetParentFolderName(WScript.ScriptFullName) & "\decoy.pdf"

If fso.FileExists(pdfPath) Then
    shell.Run """" & pdfPath & """", 1, False
Else
    MsgBox "PDF file not found:" & vbCrLf & pdfPath, 48, "File Error"
End If

Set fso = Nothing
Set shell = Nothing